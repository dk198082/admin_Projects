/**
 * CLI for purging deleted F&O work orders from the Azure PG staging mirror.
 *
 * Usage:
 *   npx tsx cli.ts 365499 365502            # DRY RUN (default): counts only
 *   npx tsx cli.ts 365499 365502 --execute  # actually delete, one transaction
 *
 * Options:
 *   --execute            Perform the deletes (default is dry run)
 *
 * Deletes are always restricted to dataareaid = 'TOUS'. (The programmatic
 * API accepts a different company, but the CLI deliberately does not, to
 * protect same-numbered orders in other companies.)
 *
 * Required env vars: AZURE_PG_HOST, AZURE_PG_DATABASE, AZURE_PG_USER,
 * AZURE_PG_PASSWORD (optional: AZURE_PG_PORT, default 5432).
 */

import pg from "pg";
import { purgeWorkOrder } from "./purgeWorkOrder.ts";

async function main() {
  const args = process.argv.slice(2);
  const execute = args.includes("--execute");
  const dataAreaId = "TOUS"; // CLI is intentionally TOUS-only; see header comment
  const unknown = args.filter((a) => a.startsWith("--") && a !== "--execute");
  const orders = args.filter((a) => !a.startsWith("--"));

  if (unknown.length > 0 || orders.length === 0) {
    if (unknown.length > 0) console.error(`Unknown option(s): ${unknown.join(", ")}`);
    console.error("Usage: node cli.ts <orderNumber> [...more] [--execute]");
    process.exit(1);
  }
  for (const key of ["AZURE_PG_HOST", "AZURE_PG_DATABASE"]) {
    if (!process.env[key]) {
      console.error(`Missing required env var: ${key}`);
      process.exit(1);
    }
  }

  const client = new pg.Client({
    host: process.env.AZURE_PG_HOST,
    database: process.env.AZURE_PG_DATABASE,
    user: process.env.AZURE_PG_SP_USER ?? process.env.AZURE_PG_USER,
    password: process.env.PG_NATIVE_PASSWORD ?? process.env.AZURE_PG_PASSWORD,
    port: parseInt(process.env.AZURE_PG_PORT ?? "5432", 10),
    ssl: true,
  });
  await client.connect();

  try {
    const result = await purgeWorkOrder(client, orders, { dryRun: !execute, dataAreaId });

    console.log(`\n${result.dryRun ? "DRY RUN — no rows deleted" : "EXECUTED — rows deleted"}`);
    console.log(`Company: ${result.dataAreaId}`);
    console.log(`Orders:  ${result.orderNumbers.join(", ")}\n`);
    const width = Math.max(...Object.keys(result.counts).map((t) => t.length));
    for (const [table, n] of Object.entries(result.counts)) {
      console.log(`  ${table.padEnd(width)}  ${n}`);
    }
    console.log(`\n  TOTAL: ${result.totalRows} row(s)`);
    if (result.dryRun && result.totalRows > 0) {
      console.log("\nRe-run with --execute to delete these rows.");
    }
  } finally {
    await client.end();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
