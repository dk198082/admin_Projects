# Work Order Purge

Removes **all data for one or more D365 F&O production orders** from the Azure
PostgreSQL BYOD staging mirror (schema `d365fo`).

## Why

The BYOD incremental export only pushes inserts/updates. When a production
order is **deleted in F&O**, its rows stay in the staging mirror forever and
keep appearing in downstream apps (Schedule Board, mobile, picking, etc.).
This tool deletes those orphaned rows safely.

> Only use this for orders that were actually deleted in F&O. If the order
> still exists in F&O, the next export will re-insert its rows.

## Portability

This folder is self-contained: it depends only on the `pg` npm package and
runs directly with `node` (Node ≥ 23, which strips TypeScript types natively;
on Node 22.6–22.x add `--experimental-strip-types`, or use `tsx`). To use it
in another project (e.g. Data Admin Suite / IT Admin Console):

1. Copy the `work-order-purge/` folder into the project.
2. `npm i pg` (and `npm i -D @types/pg` if not present).
3. Set the env vars below.

## Env vars

| Var | Purpose |
|---|---|
| `AZURE_PG_HOST` | Azure PostgreSQL host |
| `AZURE_PG_DATABASE` | Database name |
| `AZURE_PG_USER` | DB user with DELETE on `d365fo.*` (e.g. crmadmin) |
| `AZURE_PG_PASSWORD` | DB password |
| `AZURE_PG_PORT` | Optional, default 5432 |

(`AZURE_PG_SP_USER` / `PG_NATIVE_PASSWORD` are honored first if set.)

## CLI usage

```bash
# Dry run (default) — shows how many rows WOULD be deleted, per table
node cli.ts 365509

# Actually delete (single transaction)
node cli.ts 365509 --execute

# Multiple orders
node cli.ts 365499 365502 --execute
```

The CLI is deliberately restricted to `dataareaid = 'TOUS'`; the programmatic
API accepts a `dataAreaId` option for other companies if ever needed.

## Programmatic usage (e.g. behind an admin UI)

```ts
import pg from "pg";
import { purgeWorkOrder } from "./purgeWorkOrder";

const client = new pg.Client({ /* env-based config, ssl: true */ });
await client.connect();

// 1. Dry run — show the counts to the admin for confirmation
const preview = await purgeWorkOrder(client, ["365509"], { dryRun: true });

// 2. On confirmation — execute
const result = await purgeWorkOrder(client, ["365509"], { dryRun: false });
console.log(result.counts, result.totalRows);
```

## Safety

- Every DELETE is filtered by the explicit order-number list **and**
  `dataareaid` (default `TOUS`) — same-numbered orders in other companies
  (e.g. TOUK) are never touched.
- All deletes run in **one transaction**; any failure rolls everything back.
- Dry run is the default; `--execute` is required to delete.

## Tables covered

Each table below **and its `_load` loader twin** (note: PostgreSQL truncates
the resource-requirement twin's name to 63 chars):

| Table | Key column |
|---|---|
| prodproductionorderheaderstaging | productionordernumber |
| prodproductionorderbillofmaterialslinestaging | productionordernumber |
| prodproductionorderrouteoperationstaging | productionordernumber |
| prodproductionorderrouteoperationresourcerequirementstaging | productionordernumber |
| prodproductionpickinglistjournalentrystaging | productionordernumber |
| prodroutecardproductionjournalentrystaging | productionordernumber |
| prodproductionroutetransactionstaging | torefnumber |
| wrkctroperationsresourcecapacityreservationstaging | productionordernumber |

Raw SQL equivalent (per table):

```sql
DELETE FROM d365fo.<table>
WHERE <key_column> = ANY(ARRAY['365509'])
  AND dataareaid = 'TOUS';
```
